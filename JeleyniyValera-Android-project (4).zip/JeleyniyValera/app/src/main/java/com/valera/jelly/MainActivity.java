package com.valera.jelly;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.graphics.Color;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.OutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
 private WebView web;
 private TextToSpeech tts;
 private static final int SPEECH_REQUEST = 44;
 private SharedPreferences prefs;

 @Override public void onCreate(Bundle state) {
  super.onCreate(state);
  getWindow().setStatusBarColor(Color.rgb(103,49,180));
  getWindow().setNavigationBarColor(Color.rgb(55,25,105));
  prefs = getSharedPreferences("valera", MODE_PRIVATE);
  tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("ru", "RU")); });
  web = new WebView(this); web.setBackgroundColor(Color.rgb(118,66,198));
  web.getSettings().setJavaScriptEnabled(true);
  web.getSettings().setDomStorageEnabled(true);
  web.getSettings().setAllowFileAccess(true);
  web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient());
  web.addJavascriptInterface(new Bridge(), "ValeraAndroid");
  setContentView(web); web.loadUrl("file:///android_asset/index.html");
 }
 private void sendToJs(String method, String value) {
  runOnUiThread(() -> web.evaluateJavascript("window."+method+"("+JSONObject.quote(value)+")", null));
 }
 public class Bridge {
  @JavascriptInterface public void speak(String text) { runOnUiThread(() -> { if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "valera"); }); }
  @JavascriptInterface public void listen() {
   runOnUiThread(() -> {
    try {
     Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
     i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
     i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
     i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Спроси Валеру");
     startActivityForResult(i, SPEECH_REQUEST);
    } catch (Exception e) { sendToJs("onVoiceError", "Распознавание речи недоступно на этом устройстве"); }
   });
  }
  @JavascriptInterface public boolean hasKey() { return !prefs.getString("api_key", "").isEmpty(); }
  @JavascriptInterface public void setKey(String key) { prefs.edit().putString("api_key", key.trim()).apply(); }
  @JavascriptInterface public void askAI(String question) {
   new Thread(() -> {
    String apiKey = prefs.getString("api_key", "");
    if (apiKey.isEmpty()) { sendToJs("onAiError", "Добавь свой API-ключ в настройках"); return; }
    HttpURLConnection conn = null;
    try {
     conn = (HttpURLConnection)new URL("https://api.openai.com/v1/chat/completions").openConnection();
     conn.setRequestMethod("POST"); conn.setConnectTimeout(15000); conn.setReadTimeout(35000);
     conn.setDoOutput(true); conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
     conn.setRequestProperty("Authorization", "Bearer " + apiKey);
     JSONObject req = new JSONObject(); req.put("model", "gpt-4o-mini");
     JSONArray messages = new JSONArray();
     messages.put(new JSONObject().put("role", "system").put("content", "Ты Желейный Валера — добрый смешной желейный медвежонок. Отвечай на русском, понятно, дружелюбно, без длинных вступлений. Если не знаешь — честно скажи."));
     messages.put(new JSONObject().put("role", "user").put("content", question));
     req.put("messages", messages); req.put("max_tokens", 350);
     try (OutputStream os = conn.getOutputStream()) { os.write(req.toString().getBytes(StandardCharsets.UTF_8)); }
     int code = conn.getResponseCode(); InputStream is = code < 400 ? conn.getInputStream() : conn.getErrorStream();
     byte[] bytes = is.readAllBytes(); JSONObject response = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
     if (code >= 400) { String message = response.optJSONObject("error") != null ? response.optJSONObject("error").optString("message", "Ошибка API") : "Ошибка API"; sendToJs("onAiError", message); return; }
     String answer = response.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content");
     sendToJs("onAiAnswer", answer.trim());
    } catch (Exception e) { sendToJs("onAiError", "Не удалось получить ответ. Проверь интернет и API-ключ."); }
    finally { if (conn != null) conn.disconnect(); }
   }).start();
  }
 }
 @Override protected void onActivityResult(int request, int result, Intent data) {
  super.onActivityResult(request, result, data);
  if (request == SPEECH_REQUEST) {
   if (result == RESULT_OK && data != null) {
    ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
    if (matches != null && !matches.isEmpty()) sendToJs("onVoiceText", matches.get(0));
   } else sendToJs("onVoiceError", "Не расслышал. Попробуй ещё раз!");
  }
 }
 @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
 @Override public void onDestroy() { if(tts != null) { tts.stop(); tts.shutdown(); } if(web != null) web.destroy(); super.onDestroy(); }
}
